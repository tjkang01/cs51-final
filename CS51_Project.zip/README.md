# CS51 Final Project

A text classifier.  Analyzes documents based on seed data in the form of documents classified into several heuristics.

A common use case example is the automated analysis of reviews as positive or negative.